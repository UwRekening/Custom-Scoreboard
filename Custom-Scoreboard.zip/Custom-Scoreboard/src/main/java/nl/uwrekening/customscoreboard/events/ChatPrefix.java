package nl.uwrekening.customscoreboard.events;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatPrefix implements Listener {

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e){
        //if (scoreboard.Walked)
    }
}
